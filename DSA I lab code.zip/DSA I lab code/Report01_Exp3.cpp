#include <iostream>
#include <vector>

using namespace std;

int main() {
    int n; // Number of arrays and vectors
    cout << "Enter the number of arrays and vectors: ";
    cin >> n;

    int arr[n][6]; // 2D array of size n x 6
    vector<vector<int>> vec(n, vector<int>(6)); // 2D vector of size n x 6

    // Taking input for the array
    cout << "Enter " << n << " arrays (each with 6 elements):\n";
    for (int i = 0; i < n; i++) {
        cout << "Array " << i + 1 << ": ";
        for (int j = 0; j < 6; j++) {
            cin >> arr[i][j];
        }
    }

    // Taking input for the vector
    cout << "\nEnter " << n << " vectors (each with 6 elements):\n";
    for (int i = 0; i < n; i++) {
        cout << "Vector " << i + 1 << ": ";
        for (int j = 0; j < 6; j++) {
            cin >> vec[i][j];
        }
    }

    // Printing arrays
    cout << "\nStored Arrays:\n";
    for (int i = 0; i < n; i++) {
        cout << "Array " << i + 1 << ": ";
        for (int j = 0; j < 6; j++) {
            cout << arr[i][j] << " ";
        }
        cout << endl;
    }

    // Printing vectors
    cout << "\nStored Vectors:\n";
    for (int i = 0; i < n; i++) {
        cout << "Vector " << i + 1 << ": ";
        for (int j = 0; j < 6; j++) {
            cout << vec[i][j] << " ";
        }
        cout << endl;
    }

    return 0;
}


