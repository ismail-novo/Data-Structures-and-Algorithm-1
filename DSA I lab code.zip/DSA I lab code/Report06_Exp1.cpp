#include<bits/stdc++.h>
using namespace std;
int main(){
    string v;
    stack <char> s;
    cin>>v;
    for(int i=0;i<v.length();i++){
        s.push(v[i]);
    }
    while(s.empty()==false){
        cout<<s.top();
        s.pop();
    }
    return 0;
}
