#include<iostream>
using namespace std;

class Node {
public:
    int value;
    Node *next;
    Node(int v) {
        value = v;
        next = nullptr;
    }
};

class LinkedList {
public:
    Node *start;
    LinkedList() {
        start = nullptr;
    }

    void insertFirst(int v) {
        Node *newNode = new Node(v);
        newNode->next = start;
        start = newNode;
    }

    void insertLast(int v) {
        Node *newNode = new Node(v);
        if (start == nullptr) {
            start = newNode;
            return;
        }
        Node *temp = start;
        while (temp->next != nullptr) {
            temp = temp->next;
        }
        temp->next = newNode;
    }

    void deleteFirst() {
        if (start == nullptr) {
            cout << "List is empty" << endl;
            return;
        }
        Node *temp = start;
        start = start->next;
        delete temp;
    }

    void deleteLast() {
        if (start == nullptr) {
            cout << "List is empty" << endl;
            return;
        }
        if (start->next == nullptr) {
            delete start;
            start = nullptr;
            return;
        }
        Node *temp = start;
        while (temp->next->next != nullptr) {
            temp = temp->next;
        }
        delete temp->next;
        temp->next = nullptr;
    }

    void traverse() {
        if (start == nullptr) {
            cout << "List is empty" << endl;
            return;
        }
        Node *temp = start;
        while (temp != nullptr) {
            cout << temp->value << " -> ";
            temp = temp->next;
        }
        cout << "nullptr" << endl;
    }
};

int main() {
    LinkedList ob1;
    ob1.traverse();
    ob1.insertLast(10);
    ob1.insertLast(20);
    ob1.insertFirst(30);
    ob1.traverse();
    ob1.deleteFirst();
    ob1.deleteLast();
    ob1.traverse();
    return 0;
}
