#include<iostream>
using namespace std;

class Node {
public:
    int value;
    Node *next;
    Node(int v) {
        value = v;
        next = nullptr;
    }
};

class CLinkList {
public:
    Node *last;
    CLinkList() {
        last = nullptr;
    }

    void insertFirst(int v) {
        Node *n = new Node(v);
        if (last == nullptr) {
            last = n;
            last->next = last;
        } else {
            n->next = last->next;
            last->next = n;
        }
    }

    void insertLast(int v) {
        Node *n = new Node(v);
        if (last == nullptr) {
            last = n;
            last->next = last;
        } else {
            n->next = last->next;
            last->next = n;
            last = n;
        }
    }

    void traverse() {
        if (last == nullptr) {
            cout << "List is empty" << endl;
            return;
        }
        Node* temp = last->next;
        do {
            cout << temp->value << " -> ";
            temp = temp->next;
        } while (temp != last->next);
        cout << "(circular)" << endl;
    }
};

int main() {
    CLinkList ob;
    ob.traverse();
    ob.insertLast(10);
    ob.traverse();
    ob.insertLast(20);
    ob.traverse();
    ob.insertLast(30);
    ob.traverse();
    ob.insertLast(40);
    ob.traverse();
    return 0;
