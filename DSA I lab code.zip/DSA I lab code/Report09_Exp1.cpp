#include<iostream>
#include<vector>
#include<queue>

using namespace std;
class Graph{
    int V;
    vector<vector<int>>adj;
    public:
    Graph(int vertices){
    V = vertices;
    adj.resize(V);
    }

void addEdge(int u, int v){
    adj[u].push_back(v);
    adj[v].push_back(u);
}

void BFS(int start){
    vector<bool> visited(V,false);
    queue<int>q;

    visited[start] = true;
    q.push(start);

    while (!q.empty()){
        int vertex = q.front();
        q.pop();
        cout<<vertex<< " ";
        
           for(int neighbour : adj[vertex]){
              if (!visited[neighbour]){
                   visited[neighbour] = true;
                   q.push(neighbour);
              }
           }
    }
}
};
int main(){
    Graph g(5);

    g.addEdge(0,1);
    g.addEdge(0,4);
    g.addEdge(1,2);
    g.addEdge(1,3);
    g.addEdge(1,4);
    g.addEdge(2,3);
    g.addEdge(3,4);

    cout<<"BFS traversal starting from vertex 0:\n";
      g.BFS(0);

      return 0;
} 
