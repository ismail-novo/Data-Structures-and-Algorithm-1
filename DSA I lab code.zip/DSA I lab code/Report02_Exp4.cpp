#include<iostream>
#include<bits/stdc++.h>
using namespace std;

int main()
{
    int ar[6]={3,4,5,6,7,8};
    int k=7;
    int i=0;
    int j=5;

    while(i<=j)
    {
        int m=(i+j)/2;
        if(ar[m]>k)
        {
            j=m-1;
        }
        else if(ar[m]<k)
        {
            i=m+1;
        }
        else
        {
            cout<<"found";
            break;
        }
    }
    return 0;
}

