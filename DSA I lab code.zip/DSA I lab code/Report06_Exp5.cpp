#include<bits/stdc++.h>
using namespace std;

int prece(char c){
    if(c == '*' || c == '/'){
        return 10;
    }
    else if(c == '+' || c == '-'){
        return 5;
    }
    return 0;
}

int main(){
    string e, r;
    stack<char> st;

    cin >> e;

    for(int i = 0; i < e.length(); i++){
        if(isalnum(e[i])){
            r += e[i];
        }
        else if(e[i] == '('){
            st.push(e[i]);
        }
        else if(e[i] == ')'){
            while(!st.empty() && st.top() != '('){
                r += st.top();
                st.pop();
            }
            st.pop();
        }
        else{
            while(!st.empty() && prece(st.top()) >= prece(e[i])){
                r += st.top();
                st.pop();
            }
            st.push(e[i]);
        }
    }

    while(!st.empty()){
        r += st.top();
        st.pop();
    }

    cout << r;
    return 0;
}
