#include<bits/stdc++.h>
using namespace std;
int main()
{
 queue<int>q;
 vector<int>v;

    int n,k;
 cin>>n;
 cin>>k;


 for(int i=0;i<n;i++){
  int a;
  cin>>a;
  v.push_back(a);
 }
 for(int i=0;i<n;i++){
  int b;
  cin>>b;
  q.push(b);
 }
 int timer=0;
 while(q.empty()==false){
  int x = q.front();
  q.pop();
  if(v[x]>1){
   v[x]=v[x]-1;
   q.front();
  }
  else {
   v[x]=v[x]-1;
   if(x==k){
       timer=timer+1;
    break;
   }
  }
  timer=timer+1;
 }


 cout<<timer;
 return 0;

}
