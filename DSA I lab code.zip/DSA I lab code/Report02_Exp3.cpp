#include <iostream>
using namespace std;

int binarySearch(int pages[], int size, int target) {
    int low = 0, high = size - 1;

    while (low <= high) {
        int mid = low + (high - low) / 2; // Calculate middle index

        if (pages[mid] == target) {
            return mid; // Target found
        } else if (pages[mid] < target) {
            low = mid + 1; // Search the right half
        } else {
            high = mid - 1; // Search the left half
        }
    }

    return -1; // Target not found
}

int main() {
    const int totalPages = 500;
    int pages[totalPages];

    // Fill the array with page numbers (1 to 500)
    for (int i = 0; i < totalPages; i++) {
        pages[i] = i + 1;
    }

    int targetPage = 450;

    // Perform Binary Search
    int index = binarySearch(pages, totalPages, targetPage);

    // Display the result
    if (index != -1) {
        cout << "Page " << targetPage << " found at index " << index << endl;
    } else {
        cout << "Page " << targetPage << " not found in the book." << endl;
    }

    return 0;
}

