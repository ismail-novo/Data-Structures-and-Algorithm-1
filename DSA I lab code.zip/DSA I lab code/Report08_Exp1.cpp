#include <iostream>
#include <queue>
using namespace std;
class Node
{
public:
int data;
Node *left;
Node *right;
Node(int value)
{
data = value;
left = nullptr;
right = nullptr;
}
};

class Tree
{
public:
Node *root;
Tree()
{
root = nullptr;
}
void add(int value)
{
Node *n = new Node(value);
if (root == nullptr)
{
root = n;
return;
}
queue<Node *> q;
q.push(root);

while (!q.empty())
{
Node *p = q.front();
q.pop();

if (p->left == nullptr)
{
p->left = n;
return;
}
else
{
q.push(p->left);
}
if (p->right == nullptr)
{
p->right = n;
return;
}
else
{
q.push(p->right);
}
}
}
void preorder(Node *n)
{
if (n == nullptr)
{
return;
}
cout << n->data << "\t";
preorder(n->left);
preorder(n->right);
return;
}
};

int main()
{
Tree t;
t.add(2);
t.add(4);
t.add(6);
t.add(8);
t.add(10);
t.preorder(t.root);
return 0;
}
