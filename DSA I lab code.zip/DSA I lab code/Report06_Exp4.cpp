#include <bits/stdc++.h>
using namespace std;

int main() {
    vector<int> input;
    vector<int> result(5, -1);
    stack<int> s; // Corrected: use 's', not 'a'

    int temp;
    for (int i = 0; i < 5; i++) {
        cin >> temp;            // Corrected: 'temp' instead of undefined 's'
        input.push_back(temp);  // push input values to the vector
    }

    for (int i = 0; i < 5; i++) {
        while (!s.empty() && input[i] > input[s.top()]) {
            result[s.top()] = input[i];
            s.pop();
        }
        s.push(i);
    }

    for (int i = 0; i < 5; i++) {
        cout << result[i] << '\t';
    }

    return 0;
}
