#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

// Function to find the maximum number of consecutive stalls Akash can buy coffee from
int maxConsecutiveStalls(const vector<int>& stalls, int budget) {
    int maxConsecutive = 0; // To store the maximum number of consecutive stalls
    int currentSum = 0;     // To store the sum of the current window
    int left = 0;           // Left pointer of the sliding window

    // Iterate through the stalls using the right pointer
    for (int right = 0; right < stalls.size(); right++) {
        currentSum += stalls[right]; // Add the current stall's price to the window

        // If the current sum exceeds the budget, move the left pointer to the right
        while (currentSum > budget) {
            currentSum -= stalls[left];
            left++;
        }

        // Update the maximum number of consecutive stalls
        maxConsecutive = max(maxConsecutive, right - left + 1);
    }

    return maxConsecutive;
}

int main() {
    int n; // Number of stalls
    cout << "Enter the number of stalls: ";
    cin >> n;

    vector<int> stalls(n); // Vector to store the price of coffee at each stall
    cout << "Enter the price of coffee at each stall: ";
    for (int i = 0; i < n; i++) {
        cin >> stalls[i];
    }

    int budget; // Akash's budget
    cout << "Enter Ismail's budget: ";
    cin >> budget;

    // Calculate the maximum number of consecutive stalls Akash can buy coffee from
    int result = maxConsecutiveStalls(stalls, budget);

    // Output the result
    cout << "Maximum number of consecutive stalls Akash can buy coffee from: " << result << endl;

    return 0;
}
