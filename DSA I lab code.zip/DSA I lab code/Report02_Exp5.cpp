#include <iostream>
#include <string>

using namespace std;

// Function to find the pattern in the string
int findPattern(const string& str, const string& pattern) {
    int strLength = str.length();
    int patternLength = pattern.length();

    // Iterate through the string
    for (int i = 0; i <= strLength - patternLength; i++) {
        int j;

        // Check if the pattern matches starting at position i
        for (j = 0; j < patternLength; j++) {
            if (str[i + j] != pattern[j]) {
                break; // Mismatch, break out of the inner loop
            }
        }

        // If the inner loop completed without breaking, the pattern is found
        if (j == patternLength) {
            return i; // Return the starting index of the match
        }
    }

    // If no match is found, return -1
    return -1;
}

int main() {
    string str = "ABCDEABCDE";
    string pattern = "DEAB";

    // Find the pattern in the string
    int index = findPattern(str, pattern);

    // Output the result
    if (index != -1) {
        cout << "Pattern found at index: " << index << endl;
    } else {
        cout << "Pattern not found in the string." << endl;
    }

    return 0;
}

