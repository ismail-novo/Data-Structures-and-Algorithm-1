#include <iostream>
#include <vector>
using namespace std;

int main()
{
    int size, sumOfTheDotProduct = 0;

    cout << "Array size: ";

    cin >> size;

    int array1[size];
    vector<int> array2;

    for (int i = 0; i < size; i++)
    {
        int n;
        cout << "Element in [" << i << "]: ";
        cin >> n;
        array1[i] = n;
        array2.push_back(n);
    }
    cout << "The reverse dot product of the array and vector is: ";
    for (int i = 0; i < size; i++)
    {
        sumOfTheDotProduct += array1[size - 1 - i] * array2.at(i);
    }

    cout << sumOfTheDotProduct << endl;

    return 0;
}
