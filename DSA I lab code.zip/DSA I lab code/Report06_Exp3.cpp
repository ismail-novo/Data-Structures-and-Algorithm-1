#include <iostream>
#include <stack>
using namespace std;

bool isValid(string s) {
    stack<char> stk;

    for (char c : s) {
        if (c == '(' || c == '{' || c == '[') {
            stk.push(c);
        } else if (c == ')' || c == '}' || c == ']') {
            if (stk.empty()) return false;

            char top = stk.top();
            if ((c == ')' && top != '(') ||
                (c == '}' && top != '{') ||
                (c == ']' && top != '[')) {
                return false;
            }
            stk.pop();
        }
    }

    return stk.empty();  // True if all brackets matched
}

int main() {
    string input;
    cout << "Enter a string with brackets: ";
    cin >> input;

    if (isValid(input)) {
        cout << "The string is valid (balanced brackets)." << endl;
    } else {
        cout << "The string is NOT valid (unbalanced brackets)." << endl;
    }

    return 0;
}
