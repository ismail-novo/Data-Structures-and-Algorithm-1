#include <iostream>
using namespace std;

void flipMatrix(int matrix[][3], int rows, int cols) {

    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols / 2; j++) {

            swap(matrix[i][j], matrix[i][cols - 1 - j]);
        }
    }
}

void printMatrix(int matrix[][3], int rows, int cols) {
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            cout << matrix[i][j] << " ";
        }
        cout << endl;
    }
}

int main() {
    int matrix[3][3] = {
        {2, 5, 7},
        {3, 6, 9},
        {8, 1, 10}
    };

    cout << "Original Matrix:" << endl;
    printMatrix(matrix, 3, 3);

    flipMatrix(matrix, 3, 3);

    cout << "\nFlipped Matrix:" << endl;
    printMatrix(matrix, 3, 3);

    return 0;
}
